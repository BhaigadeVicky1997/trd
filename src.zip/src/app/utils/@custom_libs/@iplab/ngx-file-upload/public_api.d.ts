export * from './lib/file-upload.module';
//# sourceMappingURL=public_api.d.ts.map