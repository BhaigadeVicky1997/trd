/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@iplab/ngx-file-upload" />
export * from './public_api';
//# sourceMappingURL=iplab-ngx-file-upload.d.ts.map