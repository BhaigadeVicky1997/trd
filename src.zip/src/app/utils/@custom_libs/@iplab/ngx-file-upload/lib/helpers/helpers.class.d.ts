export declare function IsNullOrEmpty(value: any): boolean;
//# sourceMappingURL=helpers.class.d.ts.map