import * as i0 from "@angular/core";
export declare class FileUploadDropZoneComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadDropZoneComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileUploadDropZoneComponent, "file-upload-drop-zone", never, {}, {}, never, ["*"]>;
}
//# sourceMappingURL=file-upload-drop-zone.component.d.ts.map