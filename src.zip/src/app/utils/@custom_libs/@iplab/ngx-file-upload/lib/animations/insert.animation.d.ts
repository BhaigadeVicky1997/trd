import { AnimationTriggerMetadata } from '@angular/animations';
export declare const InsertAnimation: AnimationTriggerMetadata;
//# sourceMappingURL=insert.animation.d.ts.map