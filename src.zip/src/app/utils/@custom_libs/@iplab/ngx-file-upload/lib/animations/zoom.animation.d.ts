import { AnimationTriggerMetadata } from '@angular/animations';
export declare const ZoomAnimation: AnimationTriggerMetadata;
//# sourceMappingURL=zoom.animation.d.ts.map