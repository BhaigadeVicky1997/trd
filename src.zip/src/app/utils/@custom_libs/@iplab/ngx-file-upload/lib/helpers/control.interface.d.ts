export interface IFileUploadControlConfiguration {
    discardInvalid?: boolean;
    disabled?: boolean;
    multiple?: boolean;
    listVisible?: boolean;
    accept?: string[];
    native?: boolean;
}
//# sourceMappingURL=control.interface.d.ts.map