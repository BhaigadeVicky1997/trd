﻿import { Component } from '@angular/core';

@Component({
    selector: 'app-main-layout',
    templateUrl: './main-layout.component.html',
    styleUrls: ['./main-layout.component.scss']
})
/** main-layout component*/
export class MainLayoutComponent {
    /** main-layout ctor */
    constructor() {

    }
}