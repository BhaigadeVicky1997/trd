import { SafeurlPipe } from './safeurl.pipe';

describe('SafeurlPipe', () => {
  it('create an instance', () => {
    const pipe = new SafeurlPipe();
    expect(pipe).toBeTruthy();
  });
});
