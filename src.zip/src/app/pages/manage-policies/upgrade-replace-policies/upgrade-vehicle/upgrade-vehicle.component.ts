import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upgrade-vehicle',
  templateUrl: './upgrade-vehicle.component.html',
  styleUrls: ['./upgrade-vehicle.component.scss']
})
export class UpgradeVehicleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
