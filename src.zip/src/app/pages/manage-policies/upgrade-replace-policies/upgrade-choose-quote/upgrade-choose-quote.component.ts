import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upgrade-choose-quote',
  templateUrl: './upgrade-choose-quote.component.html',
  styleUrls: ['./upgrade-choose-quote.component.scss']
})
export class UpgradeChooseQuoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
