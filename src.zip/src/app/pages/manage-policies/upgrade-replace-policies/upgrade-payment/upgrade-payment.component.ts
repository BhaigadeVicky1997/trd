import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upgrade-payment',
  templateUrl: './upgrade-payment.component.html',
  styleUrls: ['./upgrade-payment.component.scss']
})
export class UpgradePaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
