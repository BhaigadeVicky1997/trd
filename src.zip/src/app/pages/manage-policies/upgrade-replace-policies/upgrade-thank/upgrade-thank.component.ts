import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upgrade-thank',
  templateUrl: './upgrade-thank.component.html',
  styleUrls: ['./upgrade-thank.component.scss']
})
export class UpgradeThankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
