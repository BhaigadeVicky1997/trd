import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-policies-thank-you',
  templateUrl: './cancel-policies-thank-you.component.html',
  styleUrls: ['./cancel-policies-thank-you.component.scss']
})
export class CancelPoliciesThankYouComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
