import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-policies',
  templateUrl: './cancel-policies.component.html',
  styleUrls: ['./cancel-policies.component.scss']
})
export class CancelPoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
