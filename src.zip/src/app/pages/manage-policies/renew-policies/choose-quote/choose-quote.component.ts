import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-quote',
  templateUrl: './choose-quote.component.html',
  styleUrls: ['./choose-quote.component.scss']
})
export class ChooseQuoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
