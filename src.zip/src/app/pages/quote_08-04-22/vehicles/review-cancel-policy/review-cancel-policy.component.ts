import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-review-cancel-policy',
  templateUrl: './review-cancel-policy.component.html',
  styles: [
  ]
})
export class ReviewCancelPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
