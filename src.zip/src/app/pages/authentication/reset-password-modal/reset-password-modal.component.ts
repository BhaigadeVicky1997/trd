import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-password-modal',
  templateUrl: './reset-password-modal.component.html',
  styleUrls: ['./reset-password-modal.component.scss']
})
export class ResetPasswordModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
