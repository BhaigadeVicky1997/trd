import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verfiy-code-modal',
  templateUrl: './verfiy-code-modal.component.html',
  styleUrls: ['./verfiy-code-modal.component.scss']
})
export class VerfiyCodeModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
