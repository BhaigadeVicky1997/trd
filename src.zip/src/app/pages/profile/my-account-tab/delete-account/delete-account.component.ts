import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-account',
  templateUrl: './delete-account.component.html',
})
export class DeleteAccountComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
