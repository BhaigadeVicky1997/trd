import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-reference',
  templateUrl: './claim-reference.component.html',
  styleUrls: ['./claim-reference.component.scss']
})
export class ClaimReferenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
