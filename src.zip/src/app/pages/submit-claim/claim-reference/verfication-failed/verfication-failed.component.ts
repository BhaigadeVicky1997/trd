import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verfication-failed',
  templateUrl: './verfication-failed.component.html',
  styleUrls: ['./verfication-failed.component.scss']
})
export class VerficationFailedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
