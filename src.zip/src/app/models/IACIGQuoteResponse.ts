import { IACIGQuote } from "./IACIGQuote";

export interface IACIGQuoteResponse {
    customerid:string,
    quote:IACIGQuote
}