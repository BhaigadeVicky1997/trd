export interface IVehicle{
  customerID: string,
  insuranceCompanyName: string,
    policyType: string,
    expiryDate: string,
    vehicleId:string,
    vehicleModel:string,
    vehicleNumber:string,
    vehicleMake:string,
    premiumAmount: string,
    additionalCoverageAmount: string,
    additionalCoverage:string,
    serviceChargeAmount: string,
    vat:string
   
}







