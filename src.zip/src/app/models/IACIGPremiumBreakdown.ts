export interface IACIGPremiumBreakdown {
    TypeCode:string,
    Amount:number,
    Percentage:number
}