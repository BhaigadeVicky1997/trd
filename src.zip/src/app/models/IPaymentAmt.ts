import { IVehicle } from "./IVehicle";

export interface IPaymentAmt{
  amount: number,
  language: string,
  vehicleList:IVehicle[],
}






