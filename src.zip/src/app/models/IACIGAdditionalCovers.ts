export interface IACIGAdditionalCovers {
    FeatureCode:string,
    FeatureDesc:string,
    FeatureAmount:number,
    TaxAmount:number
}