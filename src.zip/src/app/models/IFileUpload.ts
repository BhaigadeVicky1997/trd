export interface IFileUploadResponse {
  fileName: string;
  fullPath: string;
}
