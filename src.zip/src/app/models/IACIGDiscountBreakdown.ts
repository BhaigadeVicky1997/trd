export interface IACIGDiscountBreakdown {
    TypeCode:string,
    Amount:number,
    Percentage:number
}