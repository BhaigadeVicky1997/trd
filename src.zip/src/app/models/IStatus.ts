export interface IStatus {
  succeeded: boolean;
  message: string;
  errors: string;
}
