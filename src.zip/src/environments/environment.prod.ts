export const environment = {
  production: true,
  apiUrl: 'https://wplusapidev.aspnetdevelopment.in/api/v1/',
  fileUrl: 'https://wplusapidev.aspnetdevelopment.in/WazenUploads/',
  clientId: '232338756020-nm59sed4aufk0gtanlgoskdunmtluvin.apps.googleusercontent.com',
  appId: '270508575124274',
  firebaseConfig: {
    apiKey: "AIzaSyBR-BT2rBIVdV19KHpQIGXmCy8zb0kauGE",
    authDomain: "wazen-2087e.firebaseapp.com",
    projectId: "wazen-2087e",
    storageBucket: "wazen-2087e.appspot.com",
    messagingSenderId: "1093411183358",
    appId: "1:1093411183358:web:bd37dcc7a3bf444c6d63af"
  }
};
